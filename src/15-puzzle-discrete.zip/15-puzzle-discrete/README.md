# 15-Puzzle — Discrete Logic + Visual Animation

A C99 15-puzzle built with raylib. The puzzle rules are discrete and independent of frame time. Tile movement is animated by a separate presentation module.

## Architecture

```text
input.c
   |
   v
app.c  --------------------> animation.c
   |                              |
   v                              v
simulation.c                 TileAnimation
   |
   v
SimulationState                  render.c
(board, empty_index,            (draws logical board plus
 move_count, solved)              the animated tile)
```

### Simulation (`simulation.c`)

`SimulationState` contains only logical puzzle data:

- A row-major array of 16 tile values; `0` is the empty cell.
- The empty-cell index.
- Move count, random seed/RNG state, and completion flags.

The public move operation is:

```c
bool sim_move(SimulationState *state,
              Direction direction,
              MoveResult *result,
              EventQueue *events);
```

It validates the move and swaps two array entries immediately. It has no `dt`, velocity, position, target, or animation state. The board is solved as soon as the final logical move occurs.

### Presentation (`animation.c` and `render.c`)

A successful `sim_move()` returns a `MoveResult` describing the tile and its source/destination cells. `app.c` starts a `TileAnimation` from that result. `animation_update()` advances it using frame time, and `render.c` interpolates the tile's screen position with smoothstep easing.

Input is blocked while an animation is active. This is an application/input policy; it does not affect the puzzle rules. Pausing freezes the active animation.

## Controls

- **Enter / Space** — start or restart.
- **Arrow keys / WASD** — slide a tile toward the empty cell.
- **P / Escape** — pause / resume.
- **F3** — toggle debug overlay.

A new board is produced by making 250 random legal moves from the solved board. Therefore, every generated board is solvable.

## Build

Requirements: CMake 3.20+, a C99 compiler, and raylib 5.5. By default CMake fetches raylib 5.5 if it is not already installed.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build
./build/15_puzzle
```

To use a system-installed raylib without fetching:

```sh
cmake -S . -B build -DPUZZLE_FETCH_RAYLIB=OFF
cmake --build build
```

On macOS, install the command-line developer tools and CMake first. On Linux, install the graphics/window-system development libraries required by raylib for your distribution.

## Tests

The simulation and animation core has no raylib dependency, so its tests can run headlessly without fetching raylib:

```sh
cmake -S . -B build-tests -DPUZZLE_BUILD_GAME=OFF -DPUZZLE_BUILD_TESTS=ON
cmake --build build-tests
ctest --test-dir build-tests --output-on-failure
```

## Source layout

```text
include/       Public headers
src/           Application, simulation, animation, input, rendering, logging
tests/         Headless core tests
```
